import { writeFile } from 'node:fs/promises';
import { readEnvFile } from '../../scripts/lib/envFile.ts';

const path = process.argv[2];
if (!path) throw new Error('Expected the validated worktree seed source path');
const source = readEnvFile(path);
if (!source) throw new Error('Validated source env was not found');
const deployment = source.vars['CONVEX_DEPLOYMENT'];
const value = source.vars['VITE_CONVEX_URL'] ?? source.vars['CONVEX_URL'];
if (!deployment?.startsWith('dev:') || !value) throw new Error('Expected a hosted development deployment');
const url = new URL(value);
if (!url.hostname.endsWith('.convex.cloud') || url.protocol !== 'https:' || url.username || url.password || url.search) throw new Error('Expected a public Convex cloud URL');
const result = {url: url.origin, deployment, type: 'dev'};
await writeFile(new URL('./hosted-convex.json', import.meta.url), JSON.stringify(result, null, 2));
console.log(JSON.stringify(result));
