import { createFileRoute } from '@tanstack/react-router';
import { useState } from 'react';

export const Route = createFileRoute('/')({
  component: Home,
});

function Home() {
  const [count, setCount] = useState(0);
  return <main><h1>TanStack Start runs in Wasmer</h1><button onClick={() => setCount(count + 1)}>Count {count}</button></main>;
}
