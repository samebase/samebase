import { spawn } from 'node:child_process';
import { createWriteStream } from 'node:fs';
import { writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';

const [label, executable, ...args] = process.argv.slice(2);
if (!label || !executable) throw new Error('Expected a label and command');
const root = fileURLToPath(new URL('./', import.meta.url));
const logPath = `${root}logs/${label}.log`;
const log = createWriteStream(logPath);
const started = Date.now();
const env: NodeJS.ProcessEnv = {};
for (const key of ['PATH', 'HOME', 'TMPDIR', 'LANG', 'SSL_CERT_FILE', 'SSL_CERT_DIR']) {
  const value = process.env[key];
  if (value !== undefined) env[key] = value;
}
env.CI = '1';
env.NO_COLOR = '1';
const child = spawn(executable, args, { env, stdio: ['ignore', 'pipe', 'pipe'] });
child.stdout.pipe(log, { end: false });
child.stderr.pipe(log, { end: false });
child.stdout.pipe(process.stdout);
child.stderr.pipe(process.stderr);
const timeout = setTimeout(() => child.kill('SIGTERM'), 10 * 60 * 1000);
child.on('error', (error) => {
  log.write(`${error.stack}\n`);
  console.error(error);
});
child.on('close', async (code, signal) => {
  clearTimeout(timeout);
  log.end();
  const result = { executable, args, cwd: process.cwd(), code, signal, elapsedSeconds: (Date.now() - started) / 1000, logPath };
  await writeFile(`${root}logs/${label}.json`, JSON.stringify(result, null, 2));
  console.log(JSON.stringify(result));
  process.exitCode = code ?? 1;
});
