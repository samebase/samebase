import { execFileSync } from 'node:child_process';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { z } from './base-compatible/node_modules/zod/index.js';
import { parse } from '../../apps/samebase/node_modules/yaml/dist/index.js';

const root = fileURLToPath(new URL('../../', import.meta.url));
const target = fileURLToPath(new URL('./samebase-compatible/', import.meta.url));
const packageNames = ['sure', 'dependent', 'logo-model', 'sidebars'];
const tracked = execFileSync('git', ['ls-files', '-z'], { cwd: root, encoding: 'utf8' }).split('\0').filter(Boolean);
const copied: string[] = [];
for (const path of tracked) {
  const selected = path.startsWith('apps/samebase/') || path.startsWith('scripts/') || path.startsWith('runtime/') || packageNames.some(name => path.startsWith(`packages/${name}/`)) || ['tsconfig.strict.json', 'tsconfig.base.json', 'slogans.md', 'templates/base/src/components/SamebaseAttribution.tsx', 'specs/072_MOBILE_SIDEBAR_INTERACTIVE_DRAG_SPEC.md'].includes(path);
  if (!selected || /\.(mp4|mov|webm|pdf)$/.test(path)) continue;
  const next = join(target, path);
  await mkdir(dirname(next), { recursive: true });
  await writeFile(next, await readFile(join(root, path)));
  copied.push(path);
}
const manifestSchema = z.object({
  name: z.string(),
  dependencies: z.record(z.string(), z.string()).optional(),
  devDependencies: z.record(z.string(), z.string()).optional(),
}).passthrough();
const app = manifestSchema.parse(JSON.parse(await readFile(join(root, 'apps/samebase/package.json'), 'utf8')));
const dependencies = { ...app.dependencies };
const lock = z.object({importers: z.record(z.string(), z.object({
  dependencies: z.record(z.string(), z.object({version: z.string()})).optional(),
}))}).parse(parse(await readFile(join(root, 'pnpm-lock.yaml'), 'utf8')));
const lockedApp = lock.importers['apps/samebase']?.dependencies;
if (!lockedApp) throw new Error('Samebase dependencies missing from pnpm lockfile');
for (const [name, entry] of Object.entries(lockedApp)) {
  if (entry.version.startsWith('link:')) continue;
  dependencies[name] = entry.version.split('(')[0];
}
for (const name of packageNames) dependencies[`@samebase/${name}`] = `file:./packages/${name}`;
dependencies['@tanstack/react-start'] = '1.167.65';
dependencies['@tanstack/react-router'] = '1.169.2';
dependencies['@tanstack/router-core'] = '1.169.2';
dependencies['@tanstack/react-router-ssr-query'] = '1.167.0';
dependencies['@tanstack/react-query'] = '5.90.20';
dependencies['@tanstack/query-core'] = '5.90.20';
dependencies['@tanstack/react-query-devtools'] = '5.91.3';
dependencies.lightningcss = 'npm:lightningcss-wasm@1.33.0';
const manifest = {
  name: 'samebase-wasmer-probe', private: true, type: 'module', dependencies,
  devDependencies: {
    '@rolldown/binding-wasm32-wasi': '1.2.3',
    '@tailwindcss/oxide-wasm32-wasi': '4.3.0',
    '@tailwindcss/vite': '4.3.3',
    '@vitejs/plugin-react': '6.0.5',
    '@tanstack/virtual-file-routes': '1.161.7',
    'unplugin-typegpu': '0.12.1',
    tailwindcss: '4.3.3', vite: '8.2.0', typescript: '6.0.2', shadcn: '4.16.1',
  },
  overrides: {
    rolldown: '1.2.3', lightningcss: 'npm:lightningcss-wasm@1.33.0',
    '@tanstack/router-core': '1.169.2',
    '@rolldown/binding-wasm32-wasi': { '@emnapi/core': '2.0.0-alpha.4', '@emnapi/runtime': '2.0.0-alpha.4' },
    '@napi-rs/wasm-runtime': { '@emnapi/core': '2.0.0-alpha.4', '@emnapi/runtime': '2.0.0-alpha.4' },
  },
};
await writeFile(join(target, 'package.json'), JSON.stringify(manifest, null, 2));
for (const name of packageNames) {
  const path = join(target, 'packages', name, 'package.json');
  const source = manifestSchema.parse(JSON.parse(await readFile(path, 'utf8')));
  const next = { ...source, dependencies: { ...source.dependencies } };
  for (const local of packageNames) {
    const key = `@samebase/${local}`;
    if (key in next.dependencies) next.dependencies[key] = `file:../${local}`;
  }
  delete next.devDependencies;
  delete next.scripts;
  await writeFile(path, JSON.stringify(next, null, 2));
}
await writeFile(join(target, 'source-manifest.json'), JSON.stringify({
  commit: execFileSync('git', ['rev-parse', 'HEAD'], { cwd: root, encoding: 'utf8' }).trim(),
  files: copied,
}, null, 2));
console.log(JSON.stringify({ target, sourceFiles: copied.length }));
