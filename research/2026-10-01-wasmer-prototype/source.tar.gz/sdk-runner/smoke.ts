import { Wasmer } from '@wasmer/sdk/node';

const wasmer = new Wasmer({ cache: { directory: './cache' } });
let phase = '';
try {
  const sandbox = await wasmer.sandboxes.create({
    packages: ['syrusakbary/edgejs-quickjs-wasi@=0.1.5'],
    onPackageProgress(progress) {
      if (phase !== progress.phase) {
        phase = progress.phase;
        console.log(`Package ${phase}`);
      }
    },
  });
  try {
    const result = await sandbox.command('node', ['-e', `
      const { WASI } = require('node:wasi');
      const wasi = new WASI({ version: 'preview1', args: [], env: {}, preopens: {} });
      console.log(JSON.stringify({node: process.version, platform: process.platform, arch: process.arch, wasiFunctions: Object.keys(wasi.wasiImport).length}));
    `]).run({ timeoutMs: 60000, check: false });
    console.log(result.stdout.text());
    console.error(result.stderr.text());
    console.log(JSON.stringify({exitCode: result.exitCode, reason: result.reason}));
    process.exitCode = result.exitCode;
  } finally {
    await sandbox.close();
  }
} finally {
  await wasmer.close();
}
