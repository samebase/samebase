import { readdir, readFile, writeFile, mkdir } from 'node:fs/promises';
import { join, relative, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';
import { Wasmer } from '@wasmer/sdk/node';

const mode = process.argv[2] ?? 'build';
const preview = mode === 'preview' || mode === 'native-preview';
const source = fileURLToPath(new URL('../samebase-compatible/', import.meta.url));
const target = fileURLToPath(new URL('../samebase-output/', import.meta.url));
const port = mode === 'dev' ? 31486 : 31485;
const convexArg = process.argv.find(arg => arg.startsWith('--convex='));
const convexUrl = convexArg ? new URL(convexArg.slice('--convex='.length)).origin : null;
const files: Record<string, string | Uint8Array> = {};
for (const entry of await readdir(source, { recursive: true, withFileTypes: true })) {
  if (!entry.isFile()) continue;
  const path = join(entry.parentPath, entry.name);
  const name = relative(source, path);
  if (name.startsWith('apps/samebase/dist/') || name.startsWith('apps/samebase/dev-dist/') || name.endsWith('vite.native.config.ts') || (mode !== 'dev' && name.endsWith('.map')) || name.includes('binding-darwin-') || /\/\.(cache|tanstack|vite|vite-temp|tsr)\//.test(name)) continue;
  files[name] = await readFile(path);
}
if (preview) {
  const artifacts = mode === 'native-preview' ? join(source, 'apps/samebase/dist') : join(target, 'dist');
  for (const entry of await readdir(artifacts, {recursive: true, withFileTypes: true})) {
    if (!entry.isFile()) continue;
    const path = join(entry.parentPath, entry.name);
    files[`apps/samebase/dist/${relative(artifacts, path)}`] = await readFile(path);
  }
}
for (const name of ['sure', 'dependent', 'logo-model', 'sidebars']) {
  const prefix = `packages/${name}/`;
  for (const [path, contents] of Object.entries(files)) {
    if (path.startsWith(prefix)) files[`node_modules/@samebase/${name}/${path.slice(prefix.length)}`] = contents;
  }
}
files['node_modules/tsconfig.base.json'] = files['tsconfig.base.json'];
files['node_modules/tsconfig.strict.json'] = files['tsconfig.strict.json'];
const originalConfig = await readFile(join(source, 'apps/samebase/vite.config.ts'), 'utf8');
files['apps/samebase/vite.config.ts'] = originalConfig
  .replace('from "vite-plus"', 'from "vite"')
  .replace('crawlLinks: false,\n        enabled: true,', 'crawlLinks: false,\n        enabled: false,')
  .replace('spa: {\n        enabled: true,', 'spa: {\n        enabled: false,')
  .replace('host: "127.0.0.1",', 'host: "0.0.0.0",');
const viteCore = 'node_modules/vite/dist/node/chunks/node.js';
files[viteCore] = (await readFile(join(source, viteCore), 'utf8')).replace(
  'if (!idFsPath) return;\n\t\t\t\t\t\tif (idFsPath.endsWith(".json"))',
  'if (!idFsPath) return;\n\t\t\t\t\t\tif (id.startsWith("@samebase/")) return {id: idFsPath, external: false};\n\t\t\t\t\t\tif (idFsPath.endsWith(".json"))',
);
const loader = 'node_modules/@rolldown/binding-wasm32-wasi/rolldown-binding.wasi.cjs';
files[loader] = (await readFile(join(source, loader), 'utf8'))
  .replace(/asyncWorkPoolSize: \(function\(\) \{[\s\S]*?\}\)\(\),/, 'asyncWorkPoolSize: 0,')
  .replace('__publishWasiDispose(__napiModule.exports)\n  __registerWasiExitListener()', '__publishWasiDispose(__napiModule.exports)');
const oxideLoader = 'node_modules/@tailwindcss/oxide-wasm32-wasi/tailwindcss-oxide.wasi.cjs';
files[oxideLoader] = (await readFile(join(source, oxideLoader), 'utf8'))
  .replace(/asyncWorkPoolSize: \(function\(\) \{[\s\S]*?\}\)\(\),/, 'asyncWorkPoolSize: 0,');
const oxideCore = 'node_modules/@tailwindcss/oxide-wasm32-wasi/node_modules/@emnapi/core/dist/emnapi-core.cjs.js';
files[oxideCore] = (await readFile(join(source, oxideCore), 'utf8'))
  .replaceAll(/new Uint8Array\(wasmMemory.buffer\)\.subarray\((\w+), \1 \+ (\w+)\)\.fill\(0\);/g, `
    var zeroMemoryView = new DataView(wasmMemory.buffer);
    for (var offset = 0; offset < $2; offset++) zeroMemoryView.setUint8($1 + offset, 0);
  `)
  .replaceAll(/new Uint8Array\(wasmMemory.buffer, (\w+), (\w+)\)\.fill\(0\);/g, `
    var zeroMemoryView = new DataView(wasmMemory.buffer);
    for (var offset = 0; offset < $2; offset++) zeroMemoryView.setUint8($1 + offset, 0);
  `);
files[oxideCore.replace('.cjs.js', '.cjs.min.js')] = files[oxideCore];
const scanPaths = Object.keys(files).filter(path => /^(apps\/samebase\/src|packages\/[^/]+\/src|templates\/base\/src)\//.test(path) && /\.(tsx?|jsx?|html|css)$/.test(path) && !path.includes('.test.')).sort();
files['wasmer-oxide-scanner.cjs'] = `
  const fs = require('node:fs');
  const { Scanner: NativeScanner } = require('@tailwindcss/oxide-wasm32-wasi');
  const paths = ${JSON.stringify(scanPaths.map(path => `/workspace/${path}`))};
  let scanned;
  exports.Scanner = class Scanner {
    constructor() { this.native = new NativeScanner({sources: []}); }
    scan() {
      if (scanned) return scanned;
      const candidates = new Set();
      const scannedLines = new Set();
      let completedFiles = 0;
      for (const path of paths) {
        const extension = path.slice(path.lastIndexOf('.') + 1);
        for (const line of fs.readFileSync(path, 'utf8').split('\\n')) {
          if (!line) continue;
          const key = extension + ':' + line;
          if (scannedLines.has(key)) continue;
          scannedLines.add(key);
          for (const candidate of this.native.scanFiles([{content: line, extension}])) candidates.add(candidate);
        }
        completedFiles++;
        if (completedFiles % 25 === 0) console.log('WASMER_SCAN_PROGRESS', completedFiles, path);
      }
      scanned = [...candidates].sort();
      console.log('WASMER_TAILWIND_SCAN', JSON.stringify({files: paths.length, candidates: candidates.size}));
      return scanned;
    }
    scanFiles(input) { return this.native.scanFiles(input); }
    get files() { return paths; }
    get globs() { return []; }
  };
`;
const tailwindPlugin = 'node_modules/@tailwindcss/vite/dist/index.mjs';
files[tailwindPlugin] = (await readFile(join(source, tailwindPlugin), 'utf8'))
  .replace('from"@tailwindcss/oxide"', 'from"/workspace/wasmer-oxide-scanner.cjs"')
  .replace('this.compiler=await A', 'console.log("TAILWIND_COMPILE_BEGIN"),this.compiler=await A')
  .replace('this.scanner=new Y({sources:d})', 'console.log("TAILWIND_COMPILE_OK"),this.scanner=new Y({sources:d})')
  .replace('customCssResolver:this.customCssResolver,', 'customCssResolver:undefined,');

console.log(JSON.stringify({mode, files: Object.keys(files).length, convexUrl, port}));
const wasmer = new Wasmer({parallelism: 2, cache: {directory: './cache-minimal'}});
const sandbox = await wasmer.sandboxes.create({
  packages: ['syrusakbary/edgejs-quickjs-wasi@=0.1.5'], files, network: {mode: 'host'},
  env: {
    HOME: '/workspace', PATH: '/bin:/usr/bin:/usr/local/bin', CI: '1', NO_COLOR: '1',
    NAPI_RS_FORCE_WASI: 'error', RAYON_NUM_THREADS: '1',
    VITE_CONVEX_URL: convexUrl ?? 'http://localhost:3210',
    VITE_APP_COMMIT: '79234efeff00f070afebb94d18cc459f197284a2',
    VITE_APP_COMMIT_NUMBER: execFileSync('git', ['rev-list', '--count', 'HEAD'], {cwd: source, encoding: 'utf8'}).trim(),
    VITE_CONFIG_NATIVE_IGNORE_WARNING: 'true',
    ...(mode === 'dev' ? {CHOKIDAR_USEPOLLING: 'true', NODE_NO_WARNINGS: '1'} : {}),
    ...(preview ? {NODE_ENV: 'production'} : {}),
  },
});
const hostedProbe = convexUrl ? `
    const backendResponse = await fetch('${convexUrl}/api/query', {
      method: 'POST', headers: {'content-type': 'application/json'},
      body: JSON.stringify({path: 'deploymentProfile:getPublicDeploymentAuthPolicy', args: {}, format: 'json'}),
    });
    const backendResult = await backendResponse.json();
    console.log('CONVEX_HOSTED_QUERY', JSON.stringify({status: backendResponse.status, result: backendResult.status, value: backendResult.value}));
    if (backendResponse.status !== 200 || backendResult.status !== 'success') throw new Error('Hosted Convex public query failed');
    console.log('CONVEX_HOSTED_QUERY_OK');
  ` : '';
const body = `
  ${preview ? '' : "import { createBuilder, createServer } from 'vite';"}
  console.log('WASMER_RUNTIME', process.platform, process.arch, process.version);
  const options = {
    configFile: './vite.config.ts',
    build: {minify: false, cssMinify: false},
    ssr: {noExternal: ['@samebase/sure', '@samebase/dependent', '@samebase/logo-model', '@samebase/sidebars']},
  };
  ${mode === 'dev' ? `
    let transformed = 0;
    const server = await createServer({
      ...options,
      plugins: [{
        name: 'wasmer-disable-optimizer', enforce: 'post',
        transform(code, id) {
          transformed++;
          if (transformed % 25 === 0) console.log('DEV_TRANSFORM_PROGRESS', transformed, id);
        },
        configResolved: {order: 'post', handler(config) {
          for (const options of [config.optimizeDeps, ...Object.values(config.environments).map(environment => environment.optimizeDeps)]) {
            options.noDiscovery = true;
            options.include = [];
          }
        }},
      }],
      server: {host: '0.0.0.0', port: ${port}, strictPort: true, allowedHosts: true, watch: {usePolling: true, interval: 1000}},
      optimizeDeps: {noDiscovery: true, include: []},
    });
    await server.listen();
    ${hostedProbe}
    console.log('SAMEBASE_WASMER_READY');
  ` : `
    ${preview ? '' : `
    console.log('SAMEBASE_BUILD_BEGIN');
    const builder = await createBuilder(options);
    await builder.buildApp();
    console.log('SAMEBASE_BUILD_OK');
    `}
    console.log('SAMEBASE_SERVER_IMPORT_BEGIN');
    const { default: entry } = await import('./dist/server/server.js');
    console.log('SAMEBASE_SERVER_IMPORT_OK');
    ${hostedProbe}
    const { createServer } = await import('node:http');
    const { readFile, stat } = await import('node:fs/promises');
    const { resolve, extname } = await import('node:path');
    const mimeTypes = {'.js':'text/javascript', '.css':'text/css', '.svg':'image/svg+xml', '.png':'image/png', '.jpg':'image/jpeg', '.woff2':'font/woff2', '.ico':'image/x-icon', '.json':'application/json', '.md':'text/plain'};
    createServer(async (request, response) => {
      try {
        const url = new URL(request.url, 'http://localhost:${port}');
        const clientRoot = resolve('./dist/client');
        const asset = resolve(clientRoot, '.' + decodeURIComponent(url.pathname));
        if (asset.startsWith(clientRoot + '/') && await stat(asset).then(value => value.isFile(), () => false)) {
          response.setHeader('content-type', mimeTypes[extname(asset)] ?? 'application/octet-stream');
          response.end(await readFile(asset));
          return;
        }
        const result = await entry.fetch(new Request(url, {headers: request.headers}));
        response.statusCode = result.status;
        result.headers.forEach((value, name) => response.setHeader(name, value));
        response.end(new Uint8Array(await result.arrayBuffer()));
      } catch (error) {
        console.error(error); response.statusCode = 500; response.end(String(error));
      }
    }).listen(${port}, '0.0.0.0', () => console.log('SAMEBASE_WASMER_READY'));
  `}
`;
await sandbox.fs.writeFile('/workspace/apps/samebase/wasmer-main.generated.mjs', body);
const guest = await sandbox.command('node', ['--conditions=samebase-source', '/workspace/apps/samebase/wasmer-main.generated.mjs'], {cwd: '/workspace/apps/samebase'}).spawn({
  stdin: 'closed', stdout: 'pipe', stderr: 'pipe', ...(preview ? {} : {timeoutMs: 540000}), outputBytes: 16 * 1024 * 1024,
});
const watchdog = setTimeout(() => {console.error('Samebase host watchdog expired'); process.kill(process.pid, 'SIGTERM');}, 570000);
const ready = Promise.withResolvers<void>();
let stdout = '';
const pump = async (stream: typeof guest.stdout, output: NodeJS.WriteStream) => {
  if (stream) for await (const chunk of stream) {
    output.write(chunk);
    if (output === process.stdout) {
      stdout += new TextDecoder().decode(chunk);
      if (stdout.includes('SAMEBASE_WASMER_READY')) ready.resolve();
    }
  }
};
const streams = [pump(guest.stdout, process.stdout), pump(guest.stderr, process.stderr)];
const exit = guest.wait();
void exit.then(result => ready.reject(new Error(`Guest exited: ${result.exitCode}, ${result.reason}`)));
await ready.promise;
await mkdir(target, {recursive: true});
await writeFile(join(target, `${mode}-deployment.json`), JSON.stringify({convexUrl, port}, null, 2));
for (const route of ['/', '/docs', '/settings']) {
  const started = Date.now();
  const response = await fetch(`http://127.0.0.1:${port}${route}`, {signal: AbortSignal.timeout(mode === 'dev' ? 540000 : 30000)});
  const html = await response.text();
  const result = {route, status: response.status, bytes: html.length, containsSamebase: html.includes('Samebase'), elapsedSeconds: (Date.now() - started) / 1000, convexUrl};
  console.log('SAMEBASE_HTTP', JSON.stringify(result));
  const name = route === '/' ? 'index' : route.slice(1);
  await writeFile(join(target, `${mode}-${name}.html`), html);
  await writeFile(join(target, `${mode}-${name}.json`), JSON.stringify(result, null, 2));
  if (response.status !== 200 || !result.containsSamebase) throw new Error(`Samebase HTTP proof failed for ${route}`);
}
const copy = async (path: string) => {
  for (const entry of await sandbox.fs.readDir(`/workspace/apps/samebase/${path}`)) {
    const next = `${path}/${entry.name}`;
    if (entry.kind === 'directory') await copy(next);
    else {
      const output = join(target, next);
      await mkdir(dirname(output), {recursive: true});
      await writeFile(output, await sandbox.fs.readFile(`/workspace/apps/samebase/${next}`));
    }
  }
};
if (mode !== 'dev' && !preview) await copy('dist');
console.log('SAMEBASE_WASMER_HTTP_VERIFIED');
clearTimeout(watchdog);
if (process.argv.includes('--keep-alive')) await Promise.all([exit, ...streams]);
else process.exit(0);
