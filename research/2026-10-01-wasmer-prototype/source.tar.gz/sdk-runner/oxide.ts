import { readdir, readFile } from 'node:fs/promises';
import { join, relative } from 'node:path';
import { fileURLToPath } from 'node:url';
import { Wasmer } from '@wasmer/sdk/node';

const source = fileURLToPath(new URL('../base-compatible/', import.meta.url));
const files: Record<string, Uint8Array | string> = {};
for (const name of ['node_modules/@tailwindcss/oxide-wasm32-wasi', 'src']) {
  for (const entry of await readdir(join(source, name), {recursive: true, withFileTypes: true})) {
    if (!entry.isFile()) continue;
    const path = join(entry.parentPath, entry.name);
    files[relative(source, path)] = await readFile(path);
  }
}
const loader = 'node_modules/@tailwindcss/oxide-wasm32-wasi/tailwindcss-oxide.wasi.cjs';
files[loader] = (await readFile(join(source, loader), 'utf8')).replace(/asyncWorkPoolSize: \(function\(\) \{[\s\S]*?\}\)\(\),/, 'asyncWorkPoolSize: 0,') + `
  module.exports.__preload = async () => {
    __napiModule.PThread.allocateUnusedWorker();
    await __napiModule.PThread.loadWasmModuleToAllWorkers();
  };
`;
const core = 'node_modules/@tailwindcss/oxide-wasm32-wasi/node_modules/@emnapi/core/dist/emnapi-core.cjs.js';
files[core] = (await readFile(join(source, core), 'utf8'))
  .replaceAll(/new Uint8Array\(wasmMemory.buffer\)\.subarray\((\w+), \1 \+ (\w+)\)\.fill\(0\);/g, 'var memoryView = new DataView(wasmMemory.buffer); for(var offset = 0; offset < $2; offset++) memoryView.setUint8($1 + offset, 0);')
  .replaceAll(/new Uint8Array\(wasmMemory.buffer, (\w+), (\w+)\)\.fill\(0\);/g, 'var memoryView = new DataView(wasmMemory.buffer); for(var offset = 0; offset < $2; offset++) memoryView.setUint8($1 + offset, 0);');
const wasmer = new Wasmer({parallelism: 2, cache: {directory: './cache-minimal'}});
const sandbox = await wasmer.sandboxes.create({packages: ['syrusakbary/edgejs-quickjs-wasi@=0.1.5'], files, env: {RAYON_NUM_THREADS: '1'}});
const timer = setTimeout(() => process.kill(process.pid, 'SIGTERM'), 90000);
const guest = await sandbox.command('node', ['-e', `
  (async () => {
  const oxide = require('@tailwindcss/oxide-wasm32-wasi');
  const { Scanner } = oxide;
  console.log('OXIDE_LOADED');
  if (${process.argv.includes('--preload')}) {
    await oxide.__preload();
    console.log('OXIDE_WORKER_READY');
  }
  const scanner = new Scanner({sources: []});
  console.log('OXIDE_CONSTRUCTED');
  console.log(JSON.stringify(scanner.scanFiles([{content: 'flex text-red-500 hover:p-2', extension: 'html'}])));
  console.log('OXIDE_CONTENT_SCAN_OK');
  const fs = require('node:fs');
  const paths = ${JSON.stringify(Object.keys(files).filter(path => path.startsWith('src/') && /\.(tsx?|css)$/.test(path)))};
  const contents = paths.map(path => ({content: fs.readFileSync('/workspace/' + path, 'utf8'), extension: path.slice(path.lastIndexOf('.') + 1)}));
  console.log('OXIDE_INPUT_READ', contents.length);
  const candidates = new Set();
  for (const input of contents) {
    for (const line of input.content.split('\\n')) {
      if (!line) continue;
      for (const candidate of scanner.scanFiles([{content: line, extension: input.extension}])) candidates.add(candidate);
    }
  }
  console.log(JSON.stringify({rawCandidates: candidates.size}));
  console.log('OXIDE_ALL_CONTENT_OK');
  const project = new Scanner({sources: [{base: '/workspace/src', pattern: '**/*.tsx', negated: false}]});
  console.log('OXIDE_PROJECT_CONSTRUCTED');
  console.log(JSON.stringify({candidates: project.scan().length, files: project.files.length}));
  console.log('OXIDE_PROJECT_SCAN_OK');
  process.exit(0);
  })().catch(error => { console.error(error); process.exit(1); });
`], {cwd: '/workspace'}).spawn({stdout: 'pipe', stderr: 'pipe', timeoutMs: 60000});
const pump = async (stream: typeof guest.stdout, output: NodeJS.WriteStream) => {
  if (stream) for await (const chunk of stream) output.write(chunk);
};
try {
  const [result] = await Promise.all([guest.wait(), pump(guest.stdout, process.stdout), pump(guest.stderr, process.stderr)]);
  console.log(JSON.stringify({exitCode: result.exitCode, reason: result.reason}));
  result.check();
} finally {
  clearTimeout(timer);
  await sandbox.close();
  await wasmer.close();
}
