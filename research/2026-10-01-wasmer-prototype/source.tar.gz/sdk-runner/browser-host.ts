import { readFile, readdir } from "node:fs/promises";
import { createServer, type RequestListener } from "node:http";
import { join, relative, resolve, extname } from "node:path";
import { fileURLToPath } from "node:url";
import { transformWithOxc } from "../minimal-tanstack/node_modules/vite/dist/node/index.js";

const source = fileURLToPath(new URL("../minimal-tanstack/", import.meta.url));
const sdk = fileURLToPath(new URL("./node_modules/@wasmer/sdk/", import.meta.url));
const zod = fileURLToPath(new URL("../samebase-compatible/node_modules/zod/", import.meta.url));
const entries: { name: string; offset: number; length: number }[] = [];
const buffers: Uint8Array[] = [];
let offset = 0;
for (const entry of await readdir(source, { recursive: true, withFileTypes: true })) {
  if (!entry.isFile()) continue;
  const path = join(entry.parentPath, entry.name);
  const name = relative(source, path);
  if (name.startsWith("dist/") || name.includes("binding-darwin-") || name.includes("/.vite/"))
    continue;
  let bytes = await readFile(path);
  if (name === "node_modules/@rolldown/binding-wasm32-wasi/rolldown-binding.wasi.cjs") {
    bytes = Buffer.from(
      bytes
        .toString("utf8")
        .replace(/asyncWorkPoolSize: \(function\(\) \{[\s\S]*?\}\)\(\),/, "asyncWorkPoolSize: 0,")
        .replace(
          "__publishWasiDispose(__napiModule.exports)\n  __registerWasiExitListener()",
          "__publishWasiDispose(__napiModule.exports)",
        ),
    );
  }
  entries.push({ name, offset, length: bytes.length });
  buffers.push(bytes);
  offset += bytes.length;
}
const manifest = Buffer.from(JSON.stringify(entries));
const prefix = Buffer.alloc(4);
prefix.writeUInt32LE(manifest.length);
const archive = Buffer.concat([prefix, manifest, ...buffers]);
const code = await transformWithOxc(
  await readFile(new URL("./browser-edit.ts", import.meta.url), "utf8"),
  "browser-edit.ts",
);
const browserCode = code.code
  .replace("'@wasmer/sdk/browser'", "'/sdk/dist/index.js'")
  .replace('"@wasmer/sdk/browser"', '"/sdk/dist/index.js"')
  .replace("'../samebase-compatible/node_modules/zod/index.js'", "'/zod/index.js'")
  .replace('"../samebase-compatible/node_modules/zod/index.js"', '"/zod/index.js"');
const html = `<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Wasmer runs in the browser</title><style>body{font:16px system-ui;margin:24px}main{display:grid;grid-template-columns:1fr 1fr;gap:24px}textarea{box-sizing:border-box;width:100%;height:340px;font:16px monospace}iframe{width:100%;height:420px}pre{white-space:pre-wrap;max-height:240px;overflow:auto}button{font:inherit;margin:12px 0;padding:6px 12px}</style></head><body><h1>Wasmer runs in the browser</h1><main><section><label for="source">src/routes/index.tsx</label><textarea id="source"></textarea><button id="save" disabled>Build in browser</button><p id="status" role="status">Starting</p></section><section id="preview"></section></main><pre id="output"></pre><script type="module" src="/browser-edit.js"></script></body></html>`;
const handler: RequestListener = async (request, response) => {
  response.setHeader("Cross-Origin-Opener-Policy", "same-origin");
  response.setHeader("Cross-Origin-Embedder-Policy", "require-corp");
  response.setHeader("Cross-Origin-Resource-Policy", "cross-origin");
  response.setHeader("Cache-Control", "no-store");
  try {
    const url = new URL(request.url ?? "/", "http://127.0.0.1");
    if (url.pathname === "/" && request.socket.localPort === 31489) {
      response.setHeader("content-type", "text/html");
      response.end(html);
      return;
    }
    if (url.pathname === "/browser-edit.js") {
      response.setHeader("content-type", "text/javascript");
      response.end(browserCode);
      return;
    }
    if (url.pathname === "/project.bin") {
      response.setHeader("content-type", "application/octet-stream");
      response.end(archive);
      return;
    }
    if (url.pathname === "/.wasmer/host.html") {
      response.setHeader("content-type", "text/html");
      response.end(
        '<!doctype html><script type="module" src="/sdk/dist/service-worker-host.js"></script>',
      );
      return;
    }
    if (url.pathname === "/wasmer-service-worker.js") {
      response.setHeader("content-type", "text/javascript");
      response.end('import "/sdk/dist/service-worker.js";');
      return;
    }
    const root = url.pathname.startsWith("/sdk/")
      ? sdk
      : url.pathname.startsWith("/zod/")
        ? zod
        : undefined;
    if (!root) {
      response.statusCode = 404;
      response.end();
      return;
    }
    const path = resolve(root, "." + url.pathname.slice(4));
    if (!path.startsWith(root)) {
      response.statusCode = 404;
      response.end();
      return;
    }
    response.setHeader(
      "content-type",
      extname(path) === ".wasm" ? "application/wasm" : "text/javascript",
    );
    response.end(await readFile(path));
  } catch (error) {
    console.error(error);
    response.statusCode = 500;
    response.end(String(error));
  }
};
createServer(handler).listen(31489, "127.0.0.1", () =>
  console.log(
    "BROWSER_RUNTIME_PAGE http://127.0.0.1:31489/",
    JSON.stringify({ files: entries.length, bytes: archive.length }),
  ),
);
createServer(handler).listen(31490, "127.0.0.1", () =>
  console.log("BROWSER_HTTP_BRIDGE http://127.0.0.1:31490/"),
);
