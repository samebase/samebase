import { readdir, readFile, writeFile, mkdir } from 'node:fs/promises';
import { createServer } from 'node:http';
import { join, relative } from 'node:path';
import { fileURLToPath } from 'node:url';
import { Wasmer } from '@wasmer/sdk/node';
import { z } from '../samebase-compatible/node_modules/zod/index.js';

const source = fileURLToPath(new URL('../minimal-tanstack/', import.meta.url));
const output = fileURLToPath(new URL('../edit-output/', import.meta.url));
const appPort = 31487;
const editorPort = 31488;
const routePath = '/workspace/src/routes/index.tsx';
const initialSource = await readFile(join(source, 'src/routes/index.tsx'), 'utf8');
const files: Record<string, Uint8Array | string> = {};
for (const entry of await readdir(source, {recursive: true, withFileTypes: true})) {
  if (!entry.isFile()) continue;
  const path = join(entry.parentPath, entry.name);
  const name = relative(source, path);
  if (name.startsWith('dist/') || name.includes('binding-darwin-') || name.includes('/.vite/')) continue;
  files[name] = await readFile(path);
}
const binding = 'node_modules/@rolldown/binding-wasm32-wasi/rolldown-binding.wasi.cjs';
files[binding] = (await readFile(join(source, binding), 'utf8'))
  .replace(/asyncWorkPoolSize: \(function\(\) \{[\s\S]*?\}\)\(\),/, 'asyncWorkPoolSize: 0,')
  .replace('__publishWasiDispose(__napiModule.exports)\n  __registerWasiExitListener()', '__publishWasiDispose(__napiModule.exports)');
files['editor-build.generated.mjs'] = `
  import {createBuilder} from 'vite';
  import {tanstackStart} from '@tanstack/react-start/plugin/vite';
  import react from '@vitejs/plugin-react';
  import {readFileSync} from 'node:fs';
  console.log('EDITOR_BUILD_RUNTIME', process.platform, process.arch, process.version);
  console.log('EDITOR_BUILD_SOURCE', JSON.stringify({containsEdit: readFileSync('${routePath}', 'utf8').includes('Edited from the browser')}));
  const builder = await createBuilder({
    configFile: false, plugins: [tanstackStart(), react()],
    build: {minify: false, cssMinify: false},
  });
  await builder.buildApp();
  console.log('EDITOR_BUILD_COMPLETE');
  process.exit(0);
`;
files['editor-runtime.generated.mjs'] = `
  import {createServer} from 'node:http';
  import {readFile,stat} from 'node:fs/promises';
  import {resolve,extname} from 'node:path';
  console.log('EDITOR_GUEST_RUNTIME', process.platform, process.arch, process.version);
  createServer(async(request,response)=>{
    try {
      const url=new URL(request.url,'http://localhost:${appPort}');
      const root=resolve('./dist/client');
      const path=resolve(root,'.'+decodeURIComponent(url.pathname));
      if(path.startsWith(root+'/')&&await stat(path).then(value=>value.isFile(),()=>false)){
        response.setHeader('content-type',extname(path)==='.js'?'text/javascript':extname(path)==='.css'?'text/css':'application/octet-stream');
        response.end(await readFile(path));return;
      }
      const revision=await readFile('./build-revision.txt','utf8');
      const {default:entry}=await import('./dist/server/server.js?revision='+revision);
      const page=await entry.fetch(new Request(url,{headers:request.headers}));
      response.statusCode=page.status;
      page.headers.forEach((value,name)=>response.setHeader(name,value));
      response.end(new Uint8Array(await page.arrayBuffer()));
    } catch(error){
      console.error(error);response.statusCode=500;response.end(String(error));
    }
  }).listen(${appPort},'0.0.0.0',()=>console.log('EDITOR_GUEST_READY'));
`;
const wasmer = new Wasmer({parallelism: 2, cache: {directory: './cache-minimal'}});
const sandbox = await wasmer.sandboxes.create({
  packages: ['syrusakbary/edgejs-quickjs-wasi@=0.1.5'], files, network: {mode: 'host'},
  env: {HOME: '/workspace', CI: '1', NO_COLOR: '1', NODE_NO_WARNINGS: '1', NAPI_RS_FORCE_WASI: 'error', RAYON_NUM_THREADS: '1'},
});
const watchdog = setTimeout(() => process.kill(process.pid, 'SIGTERM'), 360000);
const build = async () => {
  const started = Date.now();
  const compiler = await sandbox.command('node', ['/workspace/editor-build.generated.mjs'], {cwd: '/workspace'}).spawn({stdin: 'closed', stdout: 'pipe', stderr: 'pipe', outputBytes: 8 * 1024 * 1024});
  const complete = Promise.withResolvers<void>();
  let output = '';
  for (const [stream, destination] of [[compiler.stdout, process.stdout], [compiler.stderr, process.stderr]] as const) {
    if (!stream) continue;
    void (async () => {
      for await (const bytes of stream) {
        destination.write(bytes);
        if (destination === process.stdout) {
          output += new TextDecoder().decode(bytes);
          if (output.includes('EDITOR_BUILD_COMPLETE')) complete.resolve();
        }
      }
    })();
  }
  void compiler.wait().then(result => complete.reject(new Error(`Compiler exited: ${result.exitCode}, ${result.reason}`)));
  await complete.promise;
  await compiler.kill();
  return (Date.now() - started) / 1000;
};
const initialBuildSeconds = await build();
let revision = 0;
await sandbox.fs.writeFile('/workspace/build-revision.txt', String(revision));
const guest = await sandbox.command('node', ['/workspace/editor-runtime.generated.mjs'], {cwd: '/workspace'}).spawn({
  stdin: 'closed', stdout: 'pipe', stderr: 'pipe', outputBytes: 8 * 1024 * 1024,
});
const ready = Promise.withResolvers<void>();
let stdout = '';
for (const [stream, destination] of [[guest.stdout, process.stdout], [guest.stderr, process.stderr]] as const) {
  if (!stream) continue;
  void (async () => {
    for await (const bytes of stream) {
      destination.write(bytes);
      if (destination === process.stdout) {
        stdout += new TextDecoder().decode(bytes);
        if (stdout.includes('EDITOR_GUEST_READY')) ready.resolve();
      }
    }
  })();
}
const exit = guest.wait();
void exit.then(result => ready.reject(new Error(`Guest exited: ${result.exitCode}, ${result.reason}`)));
await ready.promise;
await mkdir(output, {recursive: true});
const initialStarted = Date.now();
const initialResponse = await fetch(`http://127.0.0.1:${appPort}/`, {signal: AbortSignal.timeout(240000)});
const initialHtml = await initialResponse.text();
await writeFile(join(output, 'before.html'), initialHtml);
if (initialResponse.status !== 200 || !initialHtml.includes('TanStack Start runs in Wasmer')) throw new Error('Initial app page failed');
console.log('EDITOR_INITIAL_HTTP', JSON.stringify({status: initialResponse.status, seconds: (Date.now() - initialStarted) / 1000, initialBuildSeconds}));

const editorHtml = `<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Wasmer file edit test</title>
<style>body{font:16px system-ui;margin:24px}main{display:grid;grid-template-columns:1fr 1fr;gap:24px}textarea{box-sizing:border-box;width:100%;height:360px;font:16px monospace}iframe{width:100%;height:420px;border:1px solid #aaa}button{font:inherit;margin:12px 0;padding:6px 12px}</style></head><body>
<h1>Wasmer file edit test</h1><main><section><label for="source">src/routes/index.tsx</label><textarea id="source"></textarea><button id="save">Save to Wasmer</button><p id="status" role="status">Ready</p></section><section><iframe title="TanStack preview" src="http://127.0.0.1:${appPort}/"></iframe></section></main>
<script type="module">const source=document.querySelector('#source');const save=document.querySelector('#save');const status=document.querySelector('#status');const preview=document.querySelector('iframe');source.value=${JSON.stringify(initialSource)};
save.addEventListener('click',async()=>{save.disabled=true;status.textContent='Applying edit';try{const result=await fetch('/edit',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({contents:source.value})});if(!result.ok)throw new Error(await result.text());preview.src='http://127.0.0.1:${appPort}/?edit='+Date.now();status.textContent='Saved. Preview refreshed.';}catch(error){status.textContent=String(error);}finally{save.disabled=false;}});</script></body></html>`;
const editInput = z.object({contents: z.string()});
createServer(async (request, response) => {
  try {
    if (request.method === 'GET' && request.url === '/') {
      response.setHeader('content-type', 'text/html'); response.end(editorHtml); return;
    }
    if (request.method !== 'POST' || request.url !== '/edit') {response.statusCode = 404; response.end(); return;}
    request.setEncoding('utf8');
    let body = '';
    for await (const chunk of request) {
      if (typeof chunk !== 'string') throw new Error('Expected text request');
      body += chunk;
    }
    const input = editInput.parse(JSON.parse(body));
    const started = Date.now();
    await sandbox.fs.writeFile(routePath, input.contents);
    const buildSeconds = await build();
    revision++;
    await sandbox.fs.writeFile('/workspace/build-revision.txt', String(revision));
    let html = '';
    const pollStarted = Date.now();
    while (Date.now() - pollStarted < 30000) {
      const page = await fetch(`http://127.0.0.1:${appPort}/`, {signal: AbortSignal.timeout(30000)});
      html = await page.text();
      if (page.status === 200 && html.includes('Edited from the browser')) break;
      await new Promise(resolve => setTimeout(resolve, 250));
    }
    if (!html.includes('Edited from the browser')) throw new Error('Changed source did not appear in the page');
    await writeFile(join(output, 'after.html'), html);
    const result = {status: 'passed', sourcePath: routePath, seconds: (Date.now() - started) / 1000, buildSeconds, sdkFileWrite: true, buildInsideWasmer: true, iframeReload: true, wholeAppRebuild: true};
    await writeFile(join(output, 'result.json'), JSON.stringify(result, null, 2));
    console.log('EDITOR_SOURCE_UPDATE', JSON.stringify(result));
    response.setHeader('content-type', 'application/json'); response.end(JSON.stringify(result));
  } catch (error) {
    console.error(error); response.statusCode = 500; response.end(String(error));
  }
}).listen(editorPort, '127.0.0.1', () => console.log('EDITOR_READY', `http://127.0.0.1:${editorPort}/`));
clearTimeout(watchdog);
await exit;
