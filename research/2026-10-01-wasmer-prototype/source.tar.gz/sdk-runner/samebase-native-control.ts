import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { createBuilder } from '../samebase-compatible/node_modules/vite/dist/node/index.js';

const source = fileURLToPath(new URL('../samebase-compatible/apps/samebase/', import.meta.url));
const original = await readFile(new URL('../samebase-compatible/apps/samebase/vite.config.ts', import.meta.url), 'utf8');
const path = new URL('../samebase-compatible/apps/samebase/vite.native.config.ts', import.meta.url);
await writeFile(path, original.replace('from "vite-plus"', 'from "vite"')
  .replace('crawlLinks: false,\n        enabled: true,', 'crawlLinks: false,\n        enabled: false,')
  .replace('spa: {\n        enabled: true,', 'spa: {\n        enabled: false,'));
process.env['VITE_CONVEX_URL'] = 'https://quiet-robin-508.convex.cloud';
process.env['VITE_APP_COMMIT'] = '79234efeff00f070afebb94d18cc459f197284a2';
process.env['VITE_APP_COMMIT_NUMBER'] = '2066';
process.env['VITE_CONFIG_NATIVE_IGNORE_WARNING'] = 'true';
const builder = await createBuilder({
  root: source, configFile: fileURLToPath(path), build: {minify: false, cssMinify: false},
  ssr: {noExternal: ['@samebase/sure', '@samebase/dependent', '@samebase/logo-model', '@samebase/sidebars']},
});
await builder.buildApp();
await mkdir(new URL('../samebase-native-output/', import.meta.url), {recursive: true});
await writeFile(new URL('../samebase-native-output/result.json', import.meta.url), JSON.stringify({build: 'passed', source}, null, 2));
console.log('SAMEBASE_NATIVE_BUILD_OK');
