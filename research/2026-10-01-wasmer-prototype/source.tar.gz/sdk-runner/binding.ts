import { readdir, readFile } from 'node:fs/promises';
import { join, relative } from 'node:path';
import { fileURLToPath } from 'node:url';
import { Wasmer } from '@wasmer/sdk/node';

const source = fileURLToPath(new URL('../base-wasi-build/node_modules/', import.meta.url));
const packages = ['@rolldown/binding-wasm32-wasi', '@napi-rs/wasm-runtime', '@emnapi/core', '@emnapi/runtime', '@emnapi/wasi-threads', '@tybys/wasm-util', 'tslib'];
const files: Record<string, Uint8Array> = {};
for (const name of packages) {
  for (const entry of await readdir(join(source, name), {recursive: true, withFileTypes: true})) {
    if (!entry.isFile()) continue;
    const path = join(entry.parentPath, entry.name);
    files[`node_modules/${relative(source, path)}`] = await readFile(path);
  }
}
console.log(`Prepared ${Object.keys(files).length} binding files`);
const wasmer = new Wasmer({ cache: {directory: './cache'} });
const sandbox = await wasmer.sandboxes.create({
  packages: ['syrusakbary/edgejs-quickjs-wasi@=0.1.5'], files,
  env: { NAPI_RS_ASYNC_WORK_POOL_SIZE: '1' },
});
try {
  const guest = await sandbox.command('node', ['-e', `
    console.log('Loading Rolldown WASI with one worker');
    const binding = require('@rolldown/binding-wasm32-wasi');
    console.log('Rolldown loaded: ' + typeof binding.transformSync);
    const transformed = binding.transformSync('probe.ts', 'export const answer: number = 42;', {lang: 'ts'});
    console.log(JSON.stringify({code: transformed.code, errors: transformed.errors}));
    process.exit(transformed.errors.length === 0 ? 0 : 1);
  `], {cwd: '/workspace'}).spawn({stdout: 'pipe', stderr: 'pipe', timeoutMs: 60000});
  const pump = async (stream: typeof guest.stdout, output: NodeJS.WriteStream) => {
    if (stream) for await (const chunk of stream) output.write(chunk);
  };
  const [result] = await Promise.all([guest.wait(), pump(guest.stdout, process.stdout), pump(guest.stderr, process.stderr)]);
  console.log(JSON.stringify({exitCode: result.exitCode, reason: result.reason}));
  result.check();
} finally {
  await sandbox.close();
  await wasmer.close();
}
