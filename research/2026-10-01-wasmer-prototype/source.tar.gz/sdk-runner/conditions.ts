import { Wasmer } from '@wasmer/sdk/node';

const wasmer = new Wasmer({parallelism: 2, cache: {directory: './cache-minimal'}});
const sandbox = await wasmer.sandboxes.create({
  packages: ['syrusakbary/edgejs-quickjs-wasi@=0.1.5'],
  files: {
    'node_modules/condition-probe/package.json': JSON.stringify({name: 'condition-probe', type: 'module', exports: {development: './development.mjs', browser: './browser.mjs', node: './node.mjs', default: './default.mjs'}}),
    ...Object.fromEntries(['development', 'browser', 'node', 'default'].map(name => [`node_modules/condition-probe/${name}.mjs`, `export default '${name}';`])),
  },
  env: {HOME: '/workspace'},
});
for (const flags of [[], ['--conditions=node']]) {
  const result = await sandbox.command('node', [...flags, '--input-type=module', '-e', `import selected from 'condition-probe'; console.log(JSON.stringify({selected, args: process.execArgv, env: process.env.NODE_OPTIONS}));`], {cwd: '/workspace'}).run({timeoutMs: 15000, check: false});
  console.log(JSON.stringify({flags, code: result.exitCode, stdout: result.stdout.text(), stderr: result.stderr.text()}));
}
await sandbox.close();
await wasmer.close();
