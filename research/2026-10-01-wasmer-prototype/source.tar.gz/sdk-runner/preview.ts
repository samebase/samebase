import { readdir, readFile } from 'node:fs/promises';
import { join, relative } from 'node:path';
import { fileURLToPath } from 'node:url';
import { Wasmer } from '@wasmer/sdk/node';

const base = process.argv.includes('--base');
const port = base ? 31480 : 31479;
const source = fileURLToPath(new URL(base ? '../base-compatible/node_modules/' : '../minimal-tanstack/node_modules/', import.meta.url));
const artifacts = fileURLToPath(new URL(base ? '../base-output/dist/' : '../minimal-output/dist/', import.meta.url));
const files: Record<string, Uint8Array> = {};
for (const [root, prefix] of [[source, 'node_modules/'], [artifacts, 'dist/']]) {
  for (const entry of await readdir(root, {recursive: true, withFileTypes: true})) {
    if (!entry.isFile()) continue;
    const path = join(entry.parentPath, entry.name);
    files[prefix + relative(root, path)] = await readFile(path);
  }
}
const wasmer = new Wasmer({parallelism: 2, cache: {directory: './cache-minimal'}});
const sandbox = await wasmer.sandboxes.create({
  packages: ['syrusakbary/edgejs-quickjs-wasi@=0.1.5'], files,
  network: {mode: 'host'}, env: {NODE_ENV: 'production'},
});
const guest = await sandbox.command('node', ['--input-type=module', '-e', `
  import entry from './dist/server/server.js';
  import { createServer } from 'node:http';
  import { readFile } from 'node:fs/promises';
  createServer(async (request, response) => {
    try {
      const pathname = new URL(request.url, 'http://localhost:${port}').pathname;
      if (pathname.startsWith('/assets/')) {
        const bytes = await readFile('./dist/client' + pathname);
        response.setHeader('content-type', pathname.endsWith('.js') ? 'text/javascript' : 'text/css');
        response.end(bytes);
        return;
      }
      const result = await entry.fetch(new Request('http://localhost:${port}' + request.url));
      response.statusCode = result.status;
      result.headers.forEach((value, name) => response.setHeader(name, value));
      response.end(new Uint8Array(await result.arrayBuffer()));
    } catch (error) {
      console.error(error);
      response.statusCode = 500;
      response.end(String(error));
    }
  }).listen(${port}, '0.0.0.0', () => console.log('WASMER_PREVIEW_READY http://127.0.0.1:${port}'));
`], {cwd: '/workspace'}).spawn({stdin: 'closed', stdout: 'pipe', stderr: 'pipe'});
const pump = async (stream: typeof guest.stdout, output: NodeJS.WriteStream) => {
  if (stream) for await (const chunk of stream) output.write(chunk);
};
try {
  const [result] = await Promise.all([guest.wait(), pump(guest.stdout, process.stdout), pump(guest.stderr, process.stderr)]);
  result.check();
} finally {
  await sandbox.close();
  await wasmer.close();
}
