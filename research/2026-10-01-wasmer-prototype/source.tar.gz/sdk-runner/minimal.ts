import { readdir, readFile, writeFile, mkdir } from 'node:fs/promises';
import { join, relative } from 'node:path';
import { fileURLToPath } from 'node:url';
import { Wasmer } from '@wasmer/sdk/node';

const mode = process.argv[2] ?? 'build';
const base = process.argv.includes('--base');
const guestInstall = process.argv.includes('--guest-install');
const portArg = process.argv.find(arg => arg.startsWith('--port='));
const port = portArg ? Number(portArg.slice('--port='.length)) : mode === 'dev' ? 31481 : base ? 31480 : 31479;
const singleThread = process.argv.includes('--single-thread');
const source = fileURLToPath(new URL(base ? '../base-compatible/' : '../minimal-tanstack/', import.meta.url));
const files: Record<string, Uint8Array | string> = {};
for (const entry of await readdir(source, { recursive: true, withFileTypes: true })) {
  if (!entry.isFile()) continue;
  const path = join(entry.parentPath, entry.name);
  const name = relative(source, path);
  if (name.startsWith('dist/') || name.includes('binding-darwin-arm64/') || (guestInstall && name.startsWith('node_modules/'))) continue;
  files[name] = await readFile(path);
}
if (base) {
  files['vite.config.ts'] = (await readFile(join(source, 'vite.config.ts'), 'utf8'))
    .replace('from "vite-plus"', 'from "vite"');
  const prerender = 'node_modules/@tanstack/start-plugin-core/dist/esm/vite/prerender.js';
  files[prerender] = (await readFile(join(source, prerender), 'utf8'))
    .replace('port: 0,', 'host: "0.0.0.0",\n\t\t\t\tport: 31483,\n\t\t\t\tstrictPort: true,');
}
if (singleThread && !guestInstall) {
  const loader = 'node_modules/@rolldown/binding-wasm32-wasi/rolldown-binding.wasi.cjs';
  const original = await readFile(join(source, loader), 'utf8');
  files[loader] = original
    .replace(/asyncWorkPoolSize: \(function\(\) \{[\s\S]*?\}\)\(\),/, 'asyncWorkPoolSize: 0,')
    .replace('__publishWasiDispose(__napiModule.exports)\n  __registerWasiExitListener()', '__publishWasiDispose(__napiModule.exports)');
  if (base) {
    const oxideLoader = 'node_modules/@tailwindcss/oxide-wasm32-wasi/tailwindcss-oxide.wasi.cjs';
    files[oxideLoader] = (await readFile(join(source, oxideLoader), 'utf8'))
      .replace(/asyncWorkPoolSize: \(function\(\) \{[\s\S]*?\}\)\(\),/, 'asyncWorkPoolSize: 0,');
    const oxideCore = 'node_modules/@tailwindcss/oxide-wasm32-wasi/node_modules/@emnapi/core/dist/emnapi-core.cjs.js';
    files[oxideCore] = (await readFile(join(source, oxideCore), 'utf8'))
      .replaceAll(/new Uint8Array\(wasmMemory.buffer\)\.subarray\((\w+), \1 \+ (\w+)\)\.fill\(0\);/g, `
        var zeroMemoryView = new DataView(wasmMemory.buffer);
        for (var offset = 0; offset < $2; offset++) zeroMemoryView.setUint8($1 + offset, 0);
      `)
      .replaceAll(/new Uint8Array\(wasmMemory.buffer, (\w+), (\w+)\)\.fill\(0\);/g, `
        var zeroMemoryView = new DataView(wasmMemory.buffer);
        for (var offset = 0; offset < $2; offset++) zeroMemoryView.setUint8($1 + offset, 0);
      `);
  }
}
if (base && process.argv.includes('--js-scan')) {
  const paths = Object.keys(files).filter(path => path.startsWith('src/') && /\.(tsx?|jsx?|html|css)$/.test(path)).sort();
  files['wasmer-oxide-scanner.cjs'] = `
    const fs = require('node:fs');
    const { Scanner: NativeScanner } = require('@tailwindcss/oxide-wasm32-wasi');
    const paths = ${JSON.stringify(paths.map(path => `/workspace/${path}`))};
    exports.Scanner = class Scanner {
      constructor() { this.native = new NativeScanner({sources: []}); }
      scan() {
        const candidates = new Set();
        for (const path of paths) {
          const extension = path.slice(path.lastIndexOf('.') + 1);
          for (const line of fs.readFileSync(path, 'utf8').split('\\n')) {
            if (!line) continue;
            for (const candidate of this.native.scanFiles([{content: line, extension}])) candidates.add(candidate);
          }
        }
        console.log('WASMER_TAILWIND_SCAN', JSON.stringify({files: paths.length, candidates: candidates.size}));
        return [...candidates].sort();
      }
      scanFiles(input) { return this.native.scanFiles(input); }
      get files() { return paths; }
      get globs() { return []; }
    };
  `;
  const plugin = 'node_modules/@tailwindcss/vite/dist/index.mjs';
  files[plugin] = (await readFile(join(source, plugin), 'utf8'))
    .replace('from"@tailwindcss/oxide"', 'from"/workspace/wasmer-oxide-scanner.cjs"')
    .replace('this.compiler=await A', 'console.log("TAILWIND_COMPILE_BEGIN"),this.compiler=await A')
    .replace('this.scanner=new Y({sources:d})', 'console.log("TAILWIND_COMPILE_OK"),this.scanner=new Y({sources:d})')
    .replace('customCssResolver:this.customCssResolver,', 'customCssResolver:undefined,');
}
console.log(JSON.stringify({ mode, base, guestInstall, singleThread, files: Object.keys(files).length }));
const wasmer = new Wasmer({ parallelism: 2, cache: { directory: './cache-minimal' } });
const sandbox = await wasmer.sandboxes.create({
  packages: ['syrusakbary/edgejs-quickjs-wasi@=0.1.5'],
  files,
  network: { mode: 'host' },
  env: {
    HOME: '/workspace', CI: '1', NO_COLOR: '1', NAPI_RS_FORCE_WASI: 'error', NAPI_RS_ASYNC_WORK_POOL_SIZE: '1',
    ...(base ? {RAYON_NUM_THREADS: '1', DEBUG: 'tailwindcss'} : {}),
    ...(mode === 'dev' ? {DEBUG: 'vite:load,vite:transform,vite:resolve,vite:deps,vite:module-runner*'} : {}),
  },
});
if (guestInstall) {
  console.log('Installing dependencies in Wasmer');
  const install = await sandbox.command('pnpm', ['install', '--no-frozen-lockfile', '--ignore-scripts', '--reporter=append-only'], {cwd: '/workspace'}).spawn({stdin: 'closed', stdout: 'pipe', stderr: 'pipe', timeoutMs: 120000});
  const pump = async (stream: typeof install.stdout, output: NodeJS.WriteStream) => {
    if (stream) for await (const chunk of stream) output.write(chunk);
  };
  const [result] = await Promise.all([install.wait(), pump(install.stdout, process.stdout), pump(install.stderr, process.stderr)]);
  console.log(JSON.stringify({step: 'install', exitCode: result.exitCode, reason: result.reason}));
  result.check();
  const loader = '/workspace/node_modules/@rolldown/binding-wasm32-wasi/rolldown-binding.wasi.cjs';
  const original = new TextDecoder().decode(await sandbox.fs.readFile(loader));
  await sandbox.fs.writeFile(loader, original
    .replace(/asyncWorkPoolSize: \(function\(\) \{[\s\S]*?\}\)\(\),/, 'asyncWorkPoolSize: 0,')
    .replace('__publishWasiDispose(__napiModule.exports)\n  __registerWasiExitListener()', '__publishWasiDispose(__napiModule.exports)'));
}
const body = mode === 'dev' ? `
  (async () => {
    const { createServer } = await import('vite');
    const { tanstackStart } = await import('@tanstack/react-start/plugin/vite');
    const { default: react } = await import('@vitejs/plugin-react');
    const server = await createServer({
      configFile: false,
      plugins: [tanstackStart(), react(), ... (${process.argv.includes('--no-optimizer')} ? [{
        name: 'wasmer-disable-optimizer', enforce: 'post',
        configResolved: {order: 'post', handler(config) {
          for (const options of [config.optimizeDeps, ...Object.values(config.environments).map(environment => environment.optimizeDeps)]) {
            options.noDiscovery = true;
            options.include = [];
          }
        }},
      }] : [])],
      server: {host: '0.0.0.0', port: ${port}, watch: {usePolling: true, interval: 100}},
      optimizeDeps: {noDiscovery: true, include: []},
    });
    server.environments.ssr.runner.debug = (...args) => console.log('SSR_DEBUG', ...args);
    await server.listen();
    console.log('TANSTACK_SERVER_READY');
  })().catch(error => {console.error(error); process.exit(1);});
` : mode === 'binding' ? `
  const binding = require('@rolldown/binding-wasm32-wasi');
  console.log('BINDING_LOADED');
  binding.transform('probe.ts', 'export const answer: number = 42;', {lang: 'ts'}).then(result => {
    console.log(JSON.stringify({code: result.code, errors: result.errors}));
    console.log('ASYNC_TRANSFORM_OK');
    process.exit(0);
  }).catch(error => { console.error(error); process.exit(1); });
` : `
  (async () => {
    console.log('Importing Vite');
    const { createBuilder } = await import('vite');
    console.log('Importing TanStack Start');
    const { tanstackStart } = await import('@tanstack/react-start/plugin/vite');
    console.log('Importing React plugin');
    const { default: react } = await import('@vitejs/plugin-react');
    ${base ? `
      const { default: tailwindcss } = await import('@tailwindcss/vite');
      const { transpileModule, ModuleKind, ScriptTarget } = await import('typescript');
      const { readFile: readConfig, writeFile } = await import('node:fs/promises');
      const input = await readConfig('./prerender.config.ts', 'utf8');
      const output = transpileModule(input, {compilerOptions: {module: ModuleKind.ESNext, target: ScriptTarget.ES2022}});
      await writeFile('./prerender.config.generated.mjs', output.outputText);
      const { prerenderPages } = await import('./prerender.config.generated.mjs');
      const startOptions = {
        pages: prerenderPages,
        prerender: { autoStaticPathsDiscovery: false, crawlLinks: false, enabled: true },
        spa: {enabled: true, maskPath: '/#__spa-shell', prerender: {outputPath: '/index.html'}},
      };
    ` : ''}
    console.log('Creating builder');
    const builder = await createBuilder({
      configFile: false,
      plugins: [${base ? 'tailwindcss(), tanstackStart(startOptions)' : 'tanstackStart()'}, react()],
      build: { cssMinify: false, minify: false },
    });
    console.log('Building TanStack Start');
    await builder.buildApp();
    console.log('TANSTACK_BUILD_OK');
    ${mode === 'serve' ? `
      const { default: entry } = await import('./dist/server/server.js');
      const { createServer } = await import('node:http');
      const { readFile } = await import('node:fs/promises');
      createServer(async (request, response) => {
        try {
          const pathname = new URL(request.url, 'http://localhost:${port}').pathname;
          if (pathname.startsWith('/assets/')) {
            const bytes = await readFile('./dist/client' + pathname);
            response.setHeader('content-type', pathname.endsWith('.js') ? 'text/javascript' : 'text/css');
            response.end(bytes);
            return;
          }
          const result = await entry.fetch(new Request('http://localhost:${port}' + request.url));
          response.statusCode = result.status;
          result.headers.forEach((value, name) => response.setHeader(name, value));
          response.end(new Uint8Array(await result.arrayBuffer()));
        } catch (error) {
          console.error(error);
          response.statusCode = 500;
          response.end(String(error));
        }
      }).listen(${port}, '0.0.0.0', () => console.log('TANSTACK_SERVER_READY'));
    ` : 'process.exit(0);'}
  })().catch(error => { console.error(error); process.exit(1); });
`;
try {
  const guest = await sandbox.command('node', ['-e', body], { cwd: '/workspace' }).spawn({
    stdin: 'closed', stdout: 'pipe', stderr: 'pipe', timeoutMs: base ? 360000 : mode === 'dev' ? 300000 : 120000, outputBytes: 4 * 1024 * 1024,
  });
  const watchdog = setTimeout(() => { console.error('Host watchdog expired'); process.kill(process.pid, 'SIGTERM'); }, base ? 390000 : mode === 'dev' ? 330000 : 150000);
  const ready = Promise.withResolvers<void>();
  let stdout = '';
  const pump = async (stream: typeof guest.stdout, output: NodeJS.WriteStream) => {
    if (stream) for await (const chunk of stream) {
      output.write(chunk);
      if (output === process.stdout) {
        stdout += new TextDecoder().decode(chunk);
        if (stdout.includes('TANSTACK_SERVER_READY')) ready.resolve();
      }
    }
  };
  const streams = [pump(guest.stdout, process.stdout), pump(guest.stderr, process.stderr)];
  const exit = guest.wait();
  if (mode === 'serve' || mode === 'dev') {
    void exit.then(result => ready.reject(new Error(`Guest exited before serving: ${result.exitCode}, ${result.reason}`)));
    await ready.promise;
    const response = await fetch(`http://127.0.0.1:${port}/`, {signal: AbortSignal.timeout(mode === 'dev' ? 180000 : 30000)});
    const html = await response.text();
    const target = new URL(mode === 'dev' ? '../minimal-dev-output/' : base ? '../base-output/' : '../minimal-output/', import.meta.url);
    await mkdir(target, {recursive: true});
    await writeFile(new URL('response.html', target), html);
    const containsHeading = html.includes(base ? 'Samebase' : 'TanStack Start runs in Wasmer');
    await writeFile(new URL('http-result.json', target), JSON.stringify({status: response.status, bytes: html.length, containsHeading}, null, 2));
    console.log(JSON.stringify({status: response.status, bytes: html.length, containsHeading}));
    if (response.status !== 200 || !containsHeading) throw new Error('Guest SSR check failed');
    const copy = async (path: string) => {
      for (const entry of await sandbox.fs.readDir(`/workspace/${path}`)) {
        const next = `${path}/${entry.name}`;
        if (entry.kind === 'directory') await copy(next);
        else {
          const output = new URL(next, target);
          await mkdir(new URL('.', output), {recursive: true});
          await writeFile(output, await sandbox.fs.readFile(`/workspace/${next}`));
        }
      }
    };
    if (mode === 'dev') {
      const original = await readFile(join(source, 'src/routes/index.tsx'), 'utf8');
      await sandbox.fs.writeFile('/workspace/src/routes/index.tsx', original.replace('TanStack Start runs in Wasmer', 'TanStack source edit works in Wasmer'));
      const started = Date.now();
      let changed = '';
      while (Date.now() - started < 30000) {
        await new Promise(resolve => setTimeout(resolve, 250));
        changed = await (await fetch(`http://127.0.0.1:${port}/`, {signal: AbortSignal.timeout(30000)})).text();
        if (changed.includes('TanStack source edit works in Wasmer')) break;
      }
      if (!changed.includes('TanStack source edit works in Wasmer')) throw new Error('Vite did not reload the changed guest file');
      console.log('TANSTACK_DEV_EDIT_VERIFIED');
      await writeFile(new URL('edited-response.html', target), changed);
    } else await copy('dist');
    clearTimeout(watchdog);
    console.log('TANSTACK_HTTP_VERIFIED');
    if (process.argv.includes('--keep-alive')) await exit;
    else process.exit(0);
  }
  const [result] = await Promise.all([exit, ...streams]);
  clearTimeout(watchdog);
  console.log(JSON.stringify({ exitCode: result.exitCode, reason: result.reason }));
  result.check();
  if (mode === 'build') {
    const artifacts = await sandbox.fs.readDir('/workspace/dist/server');
    console.log(JSON.stringify({ artifacts }));
    const target = new URL('../minimal-output/', import.meta.url);
    await mkdir(target, { recursive: true });
    await writeFile(new URL('server.js', target), await sandbox.fs.readFile('/workspace/dist/server/server.js'));
  }
} finally {
  await sandbox.close();
  await wasmer.close();
}
