import { readdir, readFile } from 'node:fs/promises';
import { join, relative } from 'node:path';
import { fileURLToPath } from 'node:url';
import { Wasmer } from '@wasmer/sdk/node';

const modules = fileURLToPath(new URL('../base-compatible/node_modules/', import.meta.url));
const files: Record<string, Uint8Array | string> = {
  'package.json': JSON.stringify({
    name: 'wasmer-convex-anonymous-probe', private: true, type: 'module',
    dependencies: {convex: '1.46.0'},
    scripts: {dev: 'node node_modules/convex/bin/main.js dev --once --skip-push --typecheck disable --local-backend-version precompiled-2026-09-28-5c7cb5b'},
  }),
};
for (const entry of await readdir(modules, {recursive: true, withFileTypes: true})) {
  if (!entry.isFile()) continue;
  const path = join(entry.parentPath, entry.name);
  const name = relative(modules, path);
  if (name.endsWith('.map')) continue;
  files[`node_modules/${name}`] = await readFile(path);
}
const wasmer = new Wasmer({parallelism: 2, cache: {directory: './cache-minimal'}});
const sandbox = await wasmer.sandboxes.create({
  packages: ['syrusakbary/edgejs-quickjs-wasi@=0.1.5'], files,
  network: {mode: 'host'},
  env: {HOME: '/workspace', PATH: '/bin:/usr/bin:/usr/local/bin', CONVEX_AGENT_MODE: 'anonymous', CI: '1', NO_COLOR: '1'},
});
const watchdog = setTimeout(() => process.kill(process.pid, 'SIGTERM'), 90000);
try {
  const command = process.argv.includes('--direct') ? 'node' : 'pnpm';
  const args = command === 'pnpm' ? ['run', 'dev'] : ['node_modules/convex/bin/main.js', 'dev', '--once', '--skip-push', '--typecheck', 'disable', '--local-backend-version', 'precompiled-2026-09-28-5c7cb5b'];
  const guest = await sandbox.command(command, args, {cwd: '/workspace'}).spawn({stdin: 'closed', stdout: 'pipe', stderr: 'pipe', timeoutMs: 60000, outputBytes: 1024 * 1024});
  const pump = async (stream: typeof guest.stdout, output: NodeJS.WriteStream) => {
    if (stream) for await (const chunk of stream) output.write(chunk);
  };
  const [result] = await Promise.all([guest.wait(), pump(guest.stdout, process.stdout), pump(guest.stderr, process.stderr)]);
  console.log(JSON.stringify({exitCode: result.exitCode, reason: result.reason}));
  clearTimeout(watchdog);
  process.exit(0);
} finally {
  await sandbox.close();
  await wasmer.close();
}
