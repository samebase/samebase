import { Wasmer } from "@wasmer/sdk/browser";
import { z } from "../samebase-compatible/node_modules/zod/index.js";

const source = document.querySelector("#source");
const save = document.querySelector("#save");
const status = document.querySelector("#status");
const output = document.querySelector("#output");
const preview = document.querySelector("#preview");
if (
  !(source instanceof HTMLTextAreaElement) ||
  !(save instanceof HTMLButtonElement) ||
  !status ||
  !output ||
  !preview
)
  throw new Error("Missing test controls");
const log = (text: string) => {
  output.textContent += text;
};
const routePath = "/workspace/src/routes/index.tsx";
const started = performance.now();
const archive = new Uint8Array(await (await fetch("/project.bin")).arrayBuffer());
const manifestLength = new DataView(archive.buffer).getUint32(0, true);
const manifest = z
  .array(
    z.object({
      name: z.string(),
      offset: z.number().int().nonnegative(),
      length: z.number().int().nonnegative(),
    }),
  )
  .parse(JSON.parse(new TextDecoder().decode(archive.subarray(4, 4 + manifestLength))));
const files: Record<string, Uint8Array | string> = {};
for (const entry of manifest)
  files[entry.name] = archive.slice(
    4 + manifestLength + entry.offset,
    4 + manifestLength + entry.offset + entry.length,
  );
const original = files["src/routes/index.tsx"];
if (!(original instanceof Uint8Array)) throw new Error("Missing source file");
source.value = new TextDecoder().decode(original);
files["browser-build.generated.mjs"] = `
import {createBuilder} from 'vite';
import {tanstackStart} from '@tanstack/react-start/plugin/vite';
import react from '@vitejs/plugin-react';
console.log('BROWSER_BUILD_RUNTIME',process.platform,process.arch,process.version);
const builder=await createBuilder({configFile:false,plugins:[tanstackStart(),react()],build:{minify:false,cssMinify:false}});
await builder.buildApp();
console.log('BROWSER_BUILD_COMPLETE');
process.exit(0);
`;
files["browser-runtime.generated.mjs"] = `
import {createServer} from 'node:http';
import {readFile,stat} from 'node:fs/promises';
import {resolve,extname} from 'node:path';
console.log('BROWSER_GUEST_RUNTIME',process.platform,process.arch,process.version);
createServer(async(request,response)=>{
try{
const url=new URL(request.url,'http://localhost:8080');
const root=resolve('./dist/client');
const path=resolve(root,'.'+decodeURIComponent(url.pathname));
if(path.startsWith(root+'/')&&await stat(path).then(value=>value.isFile(),()=>false)){
response.setHeader('content-type',extname(path)==='.js'?'text/javascript':extname(path)==='.css'?'text/css':'application/octet-stream');
response.end(await readFile(path));return;
}
const revision=await readFile('./build-revision.txt','utf8');
const {default:entry}=await import('./dist/server/server.js?revision='+revision);
const page=await entry.fetch(new Request(url,{headers:request.headers}));
response.statusCode=page.status;page.headers.forEach((value,name)=>response.setHeader(name,value));
response.end(new Uint8Array(await page.arrayBuffer()));
}catch(error){console.error(error);response.statusCode=500;response.end(String(error));}
}).listen(8080,'0.0.0.0',()=>console.log('BROWSER_GUEST_READY'));
`;
status.textContent = "Loading Wasmer in browser";
const wasmer = new Wasmer({ parallelism: 2, cache: { namespace: "samebase-browser-proof" } });
const sandbox = await wasmer.sandboxes.create({
  packages: ["syrusakbary/edgejs-quickjs-wasi@=0.1.5"],
  files,
  network: { mode: "http" },
  env: {
    HOME: "/workspace",
    CI: "1",
    NO_COLOR: "1",
    NODE_NO_WARNINGS: "1",
    NAPI_RS_FORCE_WASI: "error",
    RAYON_NUM_THREADS: "1",
  },
  onPackageProgress(progress) {
    status.textContent = `Loading Wasmer: ${progress.phase}, ${Math.round(progress.download.downloadedBytes / 1048576)} MB`;
  },
});
const build = async () => {
  const buildStarted = performance.now();
  const compiler = await sandbox
    .command("node", ["/workspace/browser-build.generated.mjs"], { cwd: "/workspace" })
    .spawn({ stdin: "closed", stdout: "pipe", stderr: "pipe", outputBytes: 8388608 });
  const complete = Promise.withResolvers<void>();
  let stdout = "";
  for (const [stream, isStdout] of [
    [compiler.stdout, true],
    [compiler.stderr, false],
  ] as const) {
    if (!stream) continue;
    void (async () => {
      for await (const bytes of stream) {
        const text = new TextDecoder().decode(bytes);
        log(text);
        if (isStdout) {
          stdout += text;
          if (stdout.includes("BROWSER_BUILD_COMPLETE")) complete.resolve();
        }
      }
    })().catch((error) => complete.reject(error));
  }
  void compiler
    .wait()
    .then((result) =>
      complete.reject(new Error(`Compiler exited: ${result.exitCode}, ${result.reason}`)),
    );
  await complete.promise;
  await compiler.kill();
  return (performance.now() - buildStarted) / 1000;
};
status.textContent = "Building TanStack in browser Wasmer";
const initialBuildSeconds = await build();
let revision = 0;
await sandbox.fs.writeFile("/workspace/build-revision.txt", String(revision));
const guest = await sandbox
  .command("node", ["/workspace/browser-runtime.generated.mjs"], { cwd: "/workspace" })
  .spawn({ stdin: "closed", stdout: "pipe", stderr: "pipe" });
const ready = Promise.withResolvers<void>();
let stdout = "";
for (const [stream, isStdout] of [
  [guest.stdout, true],
  [guest.stderr, false],
] as const) {
  if (!stream) continue;
  void (async () => {
    for await (const bytes of stream) {
      const text = new TextDecoder().decode(bytes);
      log(text);
      if (isStdout) {
        stdout += text;
        if (stdout.includes("BROWSER_GUEST_READY")) ready.resolve();
      }
    }
  })().catch((error) => ready.reject(error));
}
void guest
  .wait()
  .then((result) => ready.reject(new Error(`Server exited: ${result.exitCode}, ${result.reason}`)));
await ready.promise;
const server = await sandbox.ports.expose(8080, {
  serviceWorker: location.hostname === "127.0.0.1" ? "http://127.0.0.1:31490" : undefined,
});
const iframe = server.createIframe({ title: "Browser Wasmer TanStack preview" });
preview.append(iframe);
status.textContent = `Ready. Built in browser in ${initialBuildSeconds.toFixed(1)} s. Startup ${((performance.now() - started) / 1000).toFixed(1)} s.`;
save.disabled = false;
save.addEventListener("click", async () => {
  save.disabled = true;
  status.textContent = "Building changed source in browser";
  try {
    await sandbox.fs.writeFile(routePath, source.value);
    const seconds = await build();
    revision++;
    await sandbox.fs.writeFile("/workspace/build-revision.txt", String(revision));
    iframe.src = `${server.url}?revision=${revision}`;
    status.textContent = `Saved. Built and refreshed in ${seconds.toFixed(1)} s.`;
  } catch (error) {
    status.textContent = String(error);
  } finally {
    save.disabled = false;
  }
});
