import { Wasmer } from '@wasmer/sdk/node';

const files: Record<string, string> = {};
const source = 'https://raw.githubusercontent.com/wasmerio/wasmer-sdk/cf70982648956b05ad79b648836eb50d9752d5e0/wasmer-sh/workspace/vinext/';
for (const path of ['package.json', 'pnpm-lock.yaml', 'vite.config.js', '.npmrc', 'styles.css', 'next-env.d.ts', 'pages/_app.js', 'pages/index.js', 'pages/api/hello.js']) {
  const response = await fetch(`${source}${path}`);
  if (!response.ok) throw new Error(`Cannot fetch ${path}: ${response.status}`);
  files[path] = await response.text();
}
const wasmer = new Wasmer({ cache: { directory: './cache' } });
try {
  const sandbox = await wasmer.sandboxes.create({
    packages: ['syrusakbary/edgejs-quickjs-wasi@=0.1.5'],
    files,
    network: { mode: 'host' },
    env: { CI: '1', NO_COLOR: '1' },
  });
  try {
    for (const step of [
      {command: 'pnpm', args: ['install', '--frozen-lockfile', '--ignore-scripts', '--reporter=append-only']},
      {command: 'node', args: ['node_modules/vinext/dist/cli.js', 'build']},
    ]) {
      console.log(`Demo ${step.command} ${step.args.join(' ')}`);
      const guest = await sandbox.command(step.command, step.args, { cwd: '/workspace' }).spawn({
        stdin: 'closed', stdout: 'pipe', stderr: 'pipe', timeoutMs: 180000,
      });
      const pump = async (stream: typeof guest.stdout, output: NodeJS.WriteStream) => {
        if (stream) for await (const chunk of stream) output.write(chunk);
      };
      const [result] = await Promise.all([guest.wait(), pump(guest.stdout, process.stdout), pump(guest.stderr, process.stderr)]);
      console.log(JSON.stringify({step, exitCode: result.exitCode, reason: result.reason}));
      result.check();
    }
    console.log(await sandbox.fs.readDir('/workspace/dist'));
  } finally {
    await sandbox.close();
  }
} finally {
  await wasmer.close();
}
