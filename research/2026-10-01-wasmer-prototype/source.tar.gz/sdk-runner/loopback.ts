import { Wasmer } from '@wasmer/sdk/node';

const wasmer = new Wasmer({parallelism: 2, cache: {directory: './cache-minimal'}});
const sandbox = await wasmer.sandboxes.create({
  packages: ['syrusakbary/edgejs-quickjs-wasi@=0.1.5'],
  network: {mode: 'host'}, env: {HOME: '/workspace'},
});
const guest = await sandbox.command('node', ['-e', `
  const {createServer} = require('node:http');
  const server = createServer((request, response) => response.end('guest loopback works'));
  server.listen(31484, '0.0.0.0', async () => {
    for (const host of ['127.0.0.1', 'localhost']) {
      try {
        const response = await fetch('http://' + host + ':31484/', {signal: AbortSignal.timeout(5000)});
        console.log(JSON.stringify({host, status: response.status, body: await response.text()}));
      } catch (error) { console.error(host, error); }
    }
    server.close();
  });
`], {cwd: '/workspace'}).spawn({stdin: 'closed', stdout: 'pipe', stderr: 'pipe', timeoutMs: 20000});
const watchdog = setTimeout(() => process.kill(process.pid, 'SIGTERM'), 30000);
const pump = async (stream: typeof guest.stdout, output: NodeJS.WriteStream) => {
  if (stream) for await (const chunk of stream) output.write(chunk);
};
try {
  const [result] = await Promise.all([guest.wait(), pump(guest.stdout, process.stdout), pump(guest.stderr, process.stderr)]);
  clearTimeout(watchdog);
  console.log(JSON.stringify({exitCode: result.exitCode, reason: result.reason}));
  result.check();
} finally {
  await sandbox.close();
  await wasmer.close();
}
