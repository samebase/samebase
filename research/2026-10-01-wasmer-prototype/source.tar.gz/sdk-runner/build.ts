import { execFileSync } from 'node:child_process';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
const sdkKind = process.argv[2] === 'original' ? 'original' : 'current';
const compatibleVite = process.argv.includes('--compatible-vite');
const { Wasmer } = sdkKind === 'original' ? await import('@wasmer/sdk2/node') : await import('@wasmer/sdk/node');

const source = fileURLToPath(new URL('../base-wasi-build/', import.meta.url));
const tracked = execFileSync('git', ['ls-files', '-z'], { cwd: source, encoding: 'utf8' }).split('\0').filter(Boolean);
const files: Record<string, Uint8Array | string> = {};
for (const path of tracked) files[path] = await readFile(`${source}${path}`);
files['.env.local'] = 'VITE_CONVEX_URL=http://127.0.0.1:3210\n';
if (compatibleVite) {
  const manifest = JSON.parse(await readFile(`${source}package.json`, 'utf8'));
  delete manifest.devDependencies['vite-plus'];
  manifest.devDependencies.vite = '8.2.0';
  manifest.devDependencies['@rolldown/binding-wasm32-wasi'] = '1.2.3';
  files['package.json'] = JSON.stringify(manifest, null, 2);
  files['pnpm-workspace.yaml'] = (await readFile(`${source}pnpm-workspace.yaml`, 'utf8')).replace('npm:@voidzero-dev/vite-plus-core@0.3.0', '8.2.0');
  files['vite.config.ts'] = (await readFile(`${source}vite.config.ts`, 'utf8')).replace('from "vite-plus"', 'from "vite"');
}

const wasmer = new Wasmer({ cache: { directory: './cache' } });
try {
  const sandbox = await wasmer.sandboxes.create({
    packages: ['syrusakbary/edgejs-quickjs-wasi@=0.1.5'],
    files,
    network: { mode: 'host' },
    env: {
      CI: '1',
      NO_COLOR: '1',
      npm_config_manage_package_manager_versions: 'false',
      npm_config_package_manager_strict: 'false',
      NAPI_RS_FORCE_WASI: 'error',
      NAPI_RS_ASYNC_WORK_POOL_SIZE: '1',
    },
  });
  try {
    const commands = [
      { name: 'install', command: 'pnpm', args: ['install', compatibleVite ? '--no-frozen-lockfile' : '--frozen-lockfile', '--ignore-scripts', '--reporter=append-only'] },
      { name: 'build', command: 'node', args: ['-e', `
        (async () => {
          console.log('Importing Vite core');
          const { createBuilder } = await import('vite');
          console.log('Loading Samebase build config');
          const builder = await createBuilder();
          console.log('Building Samebase');
          await builder.buildApp();
          console.log('SAMEBASE_BUILD_OK');
          process.exit(0);
        })().catch(error => { console.error(error); process.exit(1); });
      `] },
    ];
    for (const step of commands) {
      const started = Date.now();
      console.log(`Starting ${step.name} in Wasmer`);
      const guest = await sandbox.command(step.command, step.args, { cwd: '/workspace' }).spawn({
        stdin: 'closed', stdout: 'pipe', stderr: 'pipe', timeoutMs: 6 * 60 * 1000, outputBytes: 4 * 1024 * 1024,
      });
      const pump = async (stream: typeof guest.stdout, output: NodeJS.WriteStream) => {
        if (stream) for await (const chunk of stream) output.write(chunk);
      };
      const [result] = await Promise.all([
        guest.wait(), pump(guest.stdout, process.stdout), pump(guest.stderr, process.stderr),
      ]);
      const status = { step: step.name, exitCode: result.exitCode, reason: result.reason, elapsedSeconds: (Date.now() - started) / 1000 };
      console.log(JSON.stringify(status));
      await writeFile(new URL(`../logs/sdk-${sdkKind}-${step.name}-status.json`, import.meta.url), JSON.stringify(status, null, 2));
      result.check();
    }
    for (const path of ['dist/client/index.html', 'dist/client/about/index.html', 'dist/server/server.js']) {
      const bytes = await sandbox.fs.readFile(`/workspace/${path}`);
      console.log(JSON.stringify({artifact: path, bytes: bytes.length}));
      const target = new URL(`../sdk-build-output/${path}`, import.meta.url);
      await mkdir(new URL('.', target), { recursive: true });
      await writeFile(target, bytes);
    }
  } finally {
    await sandbox.close();
  }
} finally {
  await wasmer.close();
}
