import { readFile, writeFile } from 'node:fs/promises';

const root = new URL('./base-wasi-build/', import.meta.url);
const packageUrl = new URL('package.json', root);
const manifest = JSON.parse(await readFile(packageUrl, 'utf8'));
manifest.devDependencies['@rolldown/binding-wasm32-wasi'] = '1.2.5';
manifest.devDependencies['@tailwindcss/oxide-wasm32-wasi'] = '4.3.0';
await writeFile(packageUrl, `${JSON.stringify(manifest, null, 2)}\n`);
const workspaceUrl = new URL('pnpm-workspace.yaml', root);
const workspace = await readFile(new URL('./base/pnpm-workspace.yaml', import.meta.url), 'utf8');
await writeFile(workspaceUrl, workspace.replace('overrides:\n', 'overrides:\n  lightningcss: npm:lightningcss-wasm@1.33.0\n'));
await writeFile(new URL('.env.local', root), 'VITE_CONVEX_URL=http://127.0.0.1:3210\n');
