import { execFileSync } from 'node:child_process';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('./', import.meta.url));
const source = join(root, 'base');
const target = join(root, 'base-compatible');
const tracked = execFileSync('git', ['ls-files', '-z'], {cwd: source, encoding: 'utf8'}).split('\0').filter(Boolean);
for (const path of tracked) {
  const next = join(target, path);
  await mkdir(dirname(next), {recursive: true});
  await writeFile(next, await readFile(join(source, path)));
}
const manifest = JSON.parse(await readFile(join(source, 'package.json'), 'utf8'));
manifest.devDependencies = {
  '@rolldown/binding-wasm32-wasi': '1.2.3',
  '@tailwindcss/oxide-wasm32-wasi': '4.3.0',
  '@vitejs/plugin-react': '6.0.5',
  vite: '8.2.0',
  typescript: '6.0.2',
  shadcn: '4.16.1',
};
manifest.dependencies.lightningcss = 'npm:lightningcss-wasm@1.33.0';
manifest.dependencies['@tanstack/react-start'] = '1.168.34';
manifest.dependencies['@tanstack/react-router'] = '1.170.18';
manifest.overrides = {
  rolldown: '1.2.3',
  lightningcss: 'npm:lightningcss-wasm@1.33.0',
  '@rolldown/binding-wasm32-wasi': {
    '@emnapi/core': '2.0.0-alpha.4',
    '@emnapi/runtime': '2.0.0-alpha.4',
  },
  '@napi-rs/wasm-runtime': {
    '@emnapi/core': '2.0.0-alpha.4',
    '@emnapi/runtime': '2.0.0-alpha.4',
  },
};
delete manifest.scripts.prepare;
await writeFile(join(target, 'package.json'), JSON.stringify(manifest, null, 2));
await writeFile(join(target, '.env.local'), 'VITE_CONVEX_URL=http://127.0.0.1:3210\n');
console.log(JSON.stringify({files: tracked.length, target}));
